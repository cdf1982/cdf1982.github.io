# GlanceCam 3 Media Kit

### What is GlanceCam

GlanceCam is an IP camera viewer for Mac.
As a native client with support for standard streaming protocols, it allows to keep an eye on cameras from different brands in a secure way and without dealing with multiple clunky web apps or obsolete applications.

Launched in the Mac App Store in March 2018 and priced at $ 3.99, GlanceCam is a convenient solution that offers lots of optional customisations for the video stream.

The app is unobtrusive and easy to use, but has advanced capabilities such as Insta-zoom (hold down the mouse right button to temporarily zoom) and Always on top (float the camera window above any other); it supports 4K and audio streams, includes lots of automation-friendly features (keyboard shortcuts, the ability to send HTTP GET commands to IoT devices, support for Apple Script and a custom URL scheme) and more nerdy things.

Over 20 free updates in 3 years and attentive Users' support built a loving audience, as proved by more than 220 ratings in the App Store averaging 4+ stars.

Version 3.0 launched March 11, 2021, after two years of development, with lots of new features and improvements, some of them included in a new GlanceCam Pro optional tier.

GlanceCam is made with love by me, Cesare, a self-taught Mac and iOS developer based in Italy, but Milla's contribution figuring out the hard stuff while taking long walks cannot be discounted 🐺🏃.



### What's new in GlanceCam 3

GlanceCam 3 is the app's biggest update yet and the list of what is new and improved in the regular version is quite extensive. A few highlights:
- A new Preferences window makes easier adding, reordering and configuring video streams and tweaks; additional help is also provided in a new onboarding video, plus throughout the app in detailed tooltips and in the new, extensive FAQs.
- The aspect ratio of the video stream is now auto-detected.
- Insta-zoom and resizing is faster, more reliable and works great on ultra-wide displays.
- It's now possible to send a camera to the same level of macOS background, behind all apps and icons, so that it remains always available in the most unobtrusive way possible. A bit hacky and nerdy, but often asked for!
- Lots of new keyboard shortcuts have been added.
- Improved auto-generated email reports when requesting support or providing feedback.
- GlanceCam 3 rocks a new, stunning app icon designed by Becky Hansmeyer.


### GlanceCam Pro

GlanceCam Pro is a new tier introduced in version 3 and is designed for Users with advanced requirements, who have inspired and asked for its features.
It is offered either as a yearly subscription at $ 8.99 or as a life-time in-app purchase at $ 22.99; both purchasing methods are available since some Users strongly prefer one option over the other, but they all unlock the same feature set:
- Multi-windows support, which allows to open, resize and arrange as many windows as needed, remembering their configuration between sessions.
- An optional minimalistic user interface that removes everything but the video stream when the app is not actively interacted with.
- The ability to force a custom aspect-ratio, for non standard streams such as horizontally compressed ones or vertical cameras.
- A preferential channel for email support, guaranteed in less than 24 hours, Monday through Friday.
- 14 funny and cute custom icons to choose from, both in the new Big Sur style and in the "classic" round form (icon customisation is only shown in the Dock while GlanceCam is running).


### The future

GlanceCam currently runs great on Apple Silicon thanks to Rosetta, but a native M1 version is in the works and will launch as soon as the underlying video engine – VLCKit, which powers the famous VLC Media Player – will officially support M1 (work on this is ongoing, and progressing well, as of March 2021).

GlanceCam 3 establishes the foundations for lots of exciting future improvements, such as Onvif for auto-detecting cameras (thus removing the need of manually researching and typing in strings for most models), HomeKit cameras support, new view modes such as a single window with a fluid grid and much more.
These are all complex features that require some serious work, hence the addition of the new GlanceCam Pro tier to allow Users who really love the app to help support its future development; the plan is for the next 3 years to see even more than the 20 free updates GlanceCam already received in the first 3.

It is also possible that, when the Mac app will have everything that's needed and a bit more, GlanceCam will move to other platforms, namely iOS, iPadOS and tvOS, but let's not get ahead of ourself: GlanceCam is first and foremost a macOS app, and tries really hard to be the best at that.


### Links
- [Request GlanceCam Press version for quick testing](mailto:support@cdf1982.com?subject=Request for GlanceCam Press version)
- [Download GlanceCam on the Mac App Store](https://apps.apple.com/us/app/glancecam-ip-webcam-viewer/id1360797896)
- [Download Press assets and informations](https://cdf1982.com/glancecam-mediakit/glancecam3-media-kit.zip)
- [GlanceCam App Store video on YouTube](https://www.youtube.com/watch?v=sTU72gGfhJo)
- [GlanceCam App Store video on Vimeo](https://vimeo.com/517800053)

- [GlanceCam 2.10 website](https://cdf1982.com/glancecam.html)
- [GlanceCam Release Notes](https://cdf1982.com/glancecam/glancecam-release-notes)
- [GlanceCam Blog](https://cdf1982.com/tag/glancecam)


### Contact informations

You can contact me, Cesare, via email at [support@cdf1982.com](mailto: support@cdf1982.com) or on Twitter [@cdf1982.com](https://twitter.com/cdf1982). And of course Milla has her own [Instagram page](https://www.instagram.com/millakillapilla/)!

I'd love to hear from you and to provide any detail missing here, and I'd love even more to read what you think about my app in your publication 😉!

---
Copyright © 2021 Cesare Forelli				_Rev 1 - March 18, 2021_